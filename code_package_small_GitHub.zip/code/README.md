# CZT: leakage-averse zero-day detection and triage evaluation

Code and results for the paper **"Calibrated Zero-Day Attack Detection and Whittle-Index Alert Triage under Leakage-Averse Evaluation"** (manuscript submitted to the *International Journal of Intelligent Engineering and Systems*).

CZT evaluates thirteen zero-day attack detectors under leakage-averse protocols and passes their calibrated scores to a simulated security operations centre (SOC), where alerts are ordered by a closed-form Whittle-type index tuned with NSGA-III.

![CZT workflow](figures/fig01_workflow.png)

## Main results

| Finding | Value |
|---|---|
| Duplicated or label-conflicting records removed from UNSW-NB15 | 41.3% (257,673 to 151,239) |
| Unseen-family AUROC of the leading group (XGBoost, LightGBM, DNN, CZT-Hybrid) | 0.957 to 0.961 |
| CZT-Hybrid mean rank / median zero-day detection rate (9 hold-out folds) | 2.67 / 0.828 |
| Detection of the hardest unseen family at 1% FPR (every detector) | about 10% or less |
| Captured zero-day value at 20% SOC overload, best baseline vs tuned index | 0.569 vs 0.670 |
| Mean zero-day waiting time, best baseline vs tuned index | 30.2 vs 7.0 minutes |

## Quick start

```bash
git clone <this repository>
cd czt-zero-day-triage
pip install -r requirements.txt
python -m analysis.make_all          # rebuild figures/ and tables/ from the stored results
```

`analysis.make_all` uses only the files in `results/`. Two figures need extra inputs and are skipped with a message if those are missing: `s01_data_characterisation` needs the datasets, and `fig05_permutation_importance` needs `results/e2_fold0_models.pkl`, which is created by `python -m experiments.exp_unsw fh` or `python -m experiments.retrain_fold0`.

## Full reproduction

```bash
python scripts/download_data.py      # UNSW-NB15 and NSL-KDD into data/, with SHA-256 checks
bash run_all.sh                      # all experiments, then figures and tables
```

All commands are run from the repository root. The reported runs used Python 3.11 on two CPU cores with 7 GB of memory and no GPU; the complete pipeline takes about three to four hours. Seeds are fixed in every script, and small numerical differences can arise between library versions.

| Step | Command | Output |
|---|---|---|
| P2 family hold-out (9 folds, 13 detectors) | `python -m experiments.exp_unsw fh` | `results/e2_fh.json`, `results/e2_scores.npz` |
| P1 i.i.d. cross-validation | `python -m experiments.exp_unsw iid` | `results/e1_iid.json` |
| Effect of de-duplication | `python -m experiments.exp_dedup_effect` | `results/e1b_dedup_effect.json` |
| Latency and footprint | `python -m experiments.exp_latency` | `results/e6_latency.json` |
| SOC triage and NSGA-III tuning | `python -m experiments.exp_triage` | `results/e7_triage.json`, `results/e7_nsga3.json` |
| P3 unseen NSL-KDD attack types | `python -m experiments.exp_kdd novel` | `results/e3_kdd_novel.json` |
| P4 cross-dataset transfer | `python -m experiments.exp_kdd transfer` | `results/e4_transfer.json` |
| Figures and tables | `python -m analysis.make_all` | `figures/`, `tables/` |


## Revision (2026): added experiments

The revision replaces the simulator's catalogue match, which was derived from the true event group, by an explicit
label-free observation model, and adds tuned baselines, a learned scheduler, a label-free novelty score, a
TTL-free family hold-out, the CLAD contrastive comparator and a temporal NetFlow v3 test. The earlier results in
`results/e1_*` to `results/e7_*` are kept unchanged for comparison.

| Step | Command | Output |
|---|---|---|
| E8 catalogue sensitivity of the earlier policies | `python -m experiments.exp_triage_catalogue` | `results/e8_catalogue.json` |
| E10 refit of the leading P2 detectors, no-TTL variant, CLAD, novelty scores, split checks | `python -m experiments.exp_p2_refit` | `results/e10_refit/`, `results/e10_refit.json`, `results/e10_splits.npz` |
| E9 triage with tuned baselines, policy gradient, novelty score, 37 catalogue entries (35 distinct settings), simulator sensitivity | `python -m experiments.exp_triage_v2` | `results/e9_triage.json` |
| E9 random family partitions (K = 0 to 7) | `python -m experiments.exp_triage_v2 --partition K` | `results/e9_triage_partK.json` |
| E13 NF-UNSW-NB15-v3 temporal split (needs `../data/nfv3/NF-UNSW-NB15-v3.csv`) | `python -m experiments.exp_nfv3_temporal` | `results/e13_nfv3_temporal.json` |
| Calibration under the deployment prior | `python -m analysis.calibration_prior` | `tables/s_table_calibration_prior*.csv` |
| Full Wilcoxon / Friedman output | `python -m analysis.stats_full` | `tables/s_table_wilcoxon_full.*`, `tables/s_table_friedman_full.json` |
| Data details (features, vocabularies, cleaning counts, masks) | `python -m analysis.data_details` | `tables/s_table_features_*.csv`, `tables/s_table_cleaning_per_family.csv` |
| Revision tables and figures | `python -m analysis.detection_v2_report`, `python -m analysis.triage_v2_report` | `tables/`, `figures/` |
| E18 detection robustness (anomaly and energy baselines, inner-tuned trees, CLAD-200, majority-label cleaning, single-feature filter, P5 filter) | `python -m experiments.exp_detection_robust` | `results/e18_detection_robust.json` |
| E17 triage robustness (no-novelty tuning, policy gradient with 91 checkpoints, seeds 11/13/17, load and group control, alert precision, prototype-only novelty, prior-corrected scores; 824 tuning runs, about 4.8 h on ten cores) | `python -m experiments.exp_triage_robust` | `results/e17_robust.json` |
| E17 and E18 tables, CRN check and summary | `python -m analysis.robust_report` | `tables/s_table_e17_*.csv`, `tables/s_table_e18_*.csv`, `results/e17_summary.json` |
| Protocol sizes, triage ablations, index against tuned Risk, random partitions | `python -m analysis.supp_tables`, `python -m analysis.partitions_report` | `tables/s_table_sizes.csv`, `tables/s_table_e9_*.csv` |
| Fig. 9 of the revision (run after the two reports above) | `python -m analysis.fig9_v3` | `../manuscript/figs/fig9.png` |
| E19 CLAD with a wider learning-rate grid | `python -m experiments.exp_clad_wide` | `results/e19_clad_wide.json` |
| E20 tuned policies on fresh evaluation streams (seeds 9,000 to 9,019), pre-declared and knee-point rule | `python -m experiments.exp_triage_fresh`, then `python -m analysis.fresh_report` | `results/e20_fresh.json`, `tables/s_table_e20_*.csv`, `../manuscript/src/tables/T_fresh.md` |
| E21 training-seed variability of the leading detectors | `python -m experiments.exp_detector_seeds`, then `python -m analysis.seeds_report` | `results/e21_detector_seeds.json`, `tables/s_table_e19_clad_wide.csv`, `tables/s_table_e21_detector_seeds.csv` |
| E22 matched-load tuning in all 35 settings | `python -m experiments.exp_triage_matched`, then `python -m analysis.matched_report` | `results/e22_matched.json`, `tables/s_table_e22_matched.csv` |
| E23 site-disjoint protocol P6 (needs `../data/nfv3/NF-CICIDS2018-v3.csv`, then `python ../tools/sample_nfv3.py`) | `python -m experiments.exp_site_disjoint`, then `python -m analysis.site_report` | `results/e23_site_disjoint.json`, `tables/s_table_e23_*.csv` |
| Calibration intercept, slope, class-wise means and EM prior estimate | `python -m analysis.calibration_extra` | `tables/s_table_calibration_extra.csv` |
| Reproduction package (splits, masks, simulator streams, configuration) | `python -m analysis.export_repro` | `repro/` |

`run_revision.sh` runs E9, E13 and the partitions in sequence. `requirements-lock.txt` pins every package version
used for the revision runs (Python 3.11.16). New modules: `zdt/catalogue.py` (observation model and common random
numbers), `zdt/pg.py` (policy-gradient scheduler), `zdt/clad.py` (CLAD comparator).

## Repository layout

```
zdt/            data loading and cleaning, detectors, metrics, SOC simulator, score storage
experiments/    one script per experiment (run with python -m experiments.<name>)
analysis/       figures and tables (make_all.py runs everything)
results/        stored outputs of all experiments (JSON and a compressed score archive)
figures/        paper figures (fig01 to fig10) and supplementary figures (s01 to s13)
tables/         paper tables (T4 to T10) and supplementary tables (s_table_*)
scripts/        dataset download with checksum verification
data/           place for the datasets (not stored in the repository)
```

| Module | Content |
|---|---|
| `zdt/data.py` | loading, removal of duplicates and label conflicts, feature encoding, 18-feature shared schema |
| `zdt/models.py` | 12 detectors, B-ProtoMeta, the calibrated hybrid and Platt scaling |
| `zdt/metrics.py` | expected calibration error, reliability curves, operating-point metrics, frozen threshold |
| `zdt/triage.py` | alert generation, discrete-event SOC simulator, Whittle-type index, outcome measures |
| `zdt/io.py` | compressed storage of per-fold detector scores |

## Paper figures and tables (revised manuscript)

Figures are copied at 600 dpi to `../manuscript/figs/`; tables are written to `../manuscript/src/tables/` and
`tables/`. The manuscript is built with `python ../manuscript/build_tpl.py`.

| Paper item | Source |
|---|---|
| Figures 1 to 8 (workflow, family hold-out, optimism gap, critical difference, permutation importance, NSL-KDD, transfer, reliability) | `analysis.make_all` and `analysis.detection_v2_report` (`figures/fig01` to `fig08`) |
| Figure 9 triage gain against novelty informativeness | `analysis.fig9_v3` |
| Figures 10 and 11 candidate fronts and simulator sensitivity | `analysis.triage_v2_report` |
| Tables 5, 6, 8 to 10 (P1, P2, P3, P4, calibration and cost) | `tables/T4_p1.md` to `tables/T8_calib_cost.md` |
| Table 7 (refit, TTL-free, CLAD, P5) | `analysis.detection_v2_report` (`T_new.md`) |
| Tables 11 and 12 (deployment calibration, decisions) | `analysis.calibration_prior` (`T_dep.md`, `T_dec.md`) |
| Tables 13 to 15 (triage, index against tuned policies, ablation) | `analysis.triage_v2_report` (`T_tri.md`, `T_vs.md`, `T_abl.md`) |
| Table 16 (fresh streams) | `analysis.fresh_report` (`T_fresh.md`) |
| Supplementary tables | `python ../manuscript/build_supp.py` from the CSV files in `tables/` |

## Note on the original project data

An earlier version of this project was configured for CICAPT-IIoT 2024 and CyberSOCEval. Their raw files were not available, and the loaders silently generated synthetic stand-in data. No result from those stand-ins is used here; all results come from the public UNSW-NB15 and NSL-KDD files.

## Datasets

Please cite the dataset authors.

- N. Moustafa and J. Slay, "UNSW-NB15: A Comprehensive Data Set for Network Intrusion Detection Systems (UNSW-NB15 Network Data Set)", In: Proc. of the 2015 Military Communications and Information Systems Conference, pp. 1-6, 2015.
- M. Tavallaee, E. Bagheri, W. Lu, and A. A. Ghorbani, "A Detailed Analysis of the KDD CUP 99 Data Set", In: Proc. of the 2009 IEEE Symposium on Computational Intelligence for Security and Defense Applications, pp. 1-6, 2009.

## Citation

If you use this code, please cite the paper (full reference to be added after publication):

> Calibrated Zero-Day Attack Detection and Whittle-Index Alert Triage under Leakage-Averse Evaluation. Manuscript submitted to the International Journal of Intelligent Engineering and Systems, 2026.

## Licence

MIT, see `LICENSE`.
