#!/bin/bash
set -e
python -m experiments.exp_nfv3_temporal > results/e13_nfv3_temporal.log 2>&1
for k in 0 1 2 3 4 5 6 7; do
  python -m experiments.exp_triage_v2 --partition $k > results/e9_triage_part$k.log 2>&1
done
echo ALL_DONE
