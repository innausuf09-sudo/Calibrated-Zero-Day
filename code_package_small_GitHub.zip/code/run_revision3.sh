#!/bin/bash
# Second-round revision experiments (detection robustness, then triage robustness).
python -m experiments.exp_detection_robust > results/e18_detection_robust.log 2>&1
python -m experiments.exp_triage_robust > results/e17_robust.log 2>&1
echo ALL_DONE
