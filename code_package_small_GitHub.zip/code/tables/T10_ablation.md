| Configuration | ZCV | Wait (min) | SLA viol. |
|---|---|---|---|
| Risk baseline | 0.569 | 30.2 | 0.043 |
| CZT-D (default weights) | 0.522 | 57.0 | 0.022 |
| ↳ D without calibration | 0.514 | 60.5 | 0.023 |
| ↳ D without decay | 0.545 | 35.2 | 0.003 |
| ↳ D without deadline term | 0.547 | 59.3 | 0.069 |
| ↳ D without score (γ = 0) | 0.506 | 63.3 | 0.024 |
| CZT-TE (tuned) | 0.589 | 3.6 | 0.012 |
| ↳ TE without calibration | 0.585 | 4.2 | 0.012 |
| ↳ TE with q = 0.99 (= CZT-T) | 0.670 | 7.0 | 0.048 |
| ↳ TE with s_u = 0.5 | 0.530 | 21.3 | 0.009 |
| ↳ TE without decay | 0.589 | 3.1 | 0.007 |
| ↳ TE without score (γ = 0) | 0.586 | 3.9 | 0.013 |
